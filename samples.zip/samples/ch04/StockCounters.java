package sds.hadoop.ch04;

public enum StockCounters {
	nasdaq_price_fall, 
	nasdaq_price_same, 
	nasdaq_price_na, 
	nyse_price_fall, 
	nyse_price_same, 
	nyse_price_na;
}
